
#ifndef USART_H_
#define USART_H_
#include "stdint.h"
uint8_t sensorDetected(void);
void print_USART1(uint16_t *data, uint16_t panjang_data);
void MX_USART1_UART_Init(void);



#endif /* USART_H_ */
