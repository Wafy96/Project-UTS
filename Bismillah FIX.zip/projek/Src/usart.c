/*
 * usart.c
 *
 *  Created on: 18 Nov 2017
 *      Author: SIP
 */

#include "main.h"
#include "stm32f1xx_hal.h"
#include "stdint.h"
#include "usart.h"

int len;
char ch;
UART_HandleTypeDef huart1;
///*BEGIN printf ---------------------------------------------------------------*/
//#ifdef __GNUC__
//#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
//#else
//#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
//#endif /* __GNUC__ */
//
//PUTCHAR_PROTOTYPE
//{
////  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);
//  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 10);
//  return ch;
//}
///* END printf ---------------------------------------------------------------- */

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
  /* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
	/* Place your implementation of fputc here */
	/* e.g. write a character to the USART */
	HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 100);
//    __HAL_UART_FLUSH_DRREGISTER(&huart2);
//    fflush(stdout); // This will flush any pending printf output
	return ch;
}
/* USER CODE END PFP */

/*USART2 Init*/
void MX_USART1_UART_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	__HAL_RCC_USART1_CLK_ENABLE();

//	GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
//	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//	GPIO_InitStruct.Pull = GPIO_PULLUP;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart1);
}

/*end USART2 Init*/
void print_USART1(uint16_t *data, uint16_t panjang_data){
	HAL_UART_Transmit(&huart1, data, panjang_data, 100);
}
void Serial_print(char buffer[100]){
	len=strlen(buffer);
	print_USART1(buffer, len);
}
